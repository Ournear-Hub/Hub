<?php

namespace App\Services;

use App\Enums\ApplicationStatus;
use App\Mail\ApplicationRejectedMail;
use App\Mail\ApplicationSelectedMail;
use App\Mail\InterviewScheduledMail;
use App\Models\Application;
use App\Models\ApplicationInterview;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class RecruitmentNotificationService
{
    public function notifyStatusChanged(Application $application, ApplicationStatus $from, ApplicationStatus $to): void
    {
        if ($from === $to) {
            return;
        }

        $mailable = match ($to) {
            ApplicationStatus::Rejected => new ApplicationRejectedMail($application),
            ApplicationStatus::Selected => new ApplicationSelectedMail($application),
            default => null,
        };

        if ($mailable === null) {
            return;
        }

        $this->queueToApplicationEmail($application, $mailable);
    }

    public function notifyInterviewScheduled(Application $application, ApplicationInterview $interview): void
    {
        $this->queueToApplicationEmail($application, new InterviewScheduledMail($application, $interview));
    }

    private function queueToApplicationEmail(Application $application, Mailable $mailable): void
    {
        $email = strtolower(trim((string) $application->email));

        if (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return;
        }

        try {
            Mail::to($email)->send($mailable);
        } catch (\Throwable $exception) {
            Log::warning('Operational email could not be queued.', [
                'mailable' => $mailable::class,
                'application_id' => $application->id,
                'message' => $exception->getMessage(),
            ]);
        }
    }
}
