<?php $__env->startComponent('mail::message'); ?>
# Message received

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($enquiry->full_name); ?>,

Thank you for contacting OurNear Talent. We have received your message and will respond as soon as we can.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/contact-enquiry-submitted-submitter.blade.php ENDPATH**/ ?>