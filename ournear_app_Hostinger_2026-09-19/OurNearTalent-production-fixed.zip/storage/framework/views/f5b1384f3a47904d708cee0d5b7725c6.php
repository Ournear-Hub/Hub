<?php $__env->startComponent('mail::message'); ?>
# New job application

**<?php echo new \Illuminate\Support\EncodedHtmlString($application->full_name); ?>** applied for **<?php echo new \Illuminate\Support\EncodedHtmlString($job?->title ?? 'a role'); ?>**.

- Email: <?php echo new \Illuminate\Support\EncodedHtmlString($application->email); ?>

- Mobile: <?php echo new \Illuminate\Support\EncodedHtmlString($application->mobile); ?>

- Location: <?php echo new \Illuminate\Support\EncodedHtmlString($application->current_location); ?>


<?php $__env->startComponent('mail::button', ['url' => $adminUrl]); ?>
Open in admin
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/application-submitted-admin.blade.php ENDPATH**/ ?>