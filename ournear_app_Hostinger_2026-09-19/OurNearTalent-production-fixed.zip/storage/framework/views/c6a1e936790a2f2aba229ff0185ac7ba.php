<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>