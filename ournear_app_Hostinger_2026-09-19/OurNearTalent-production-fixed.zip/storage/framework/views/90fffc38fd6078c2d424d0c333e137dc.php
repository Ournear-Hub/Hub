<?php $__env->startComponent('mail::message'); ?>
# Enquiry received

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($enquiry->contact_person); ?>,

Thank you for contacting OurNear Talent about workforce for **<?php echo new \Illuminate\Support\EncodedHtmlString($enquiry->company_name); ?>**. We have received your request and will be in touch.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/employer-enquiry-submitted-employer.blade.php ENDPATH**/ ?>