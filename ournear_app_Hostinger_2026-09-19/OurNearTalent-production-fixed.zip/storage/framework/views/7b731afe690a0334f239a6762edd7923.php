<?php $__env->startComponent('mail::message'); ?>
# Application update

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($application->full_name); ?>,

Thank you for applying for **<?php echo new \Illuminate\Support\EncodedHtmlString($job?->title ?? 'this role'); ?>**. After careful review, we will not be progressing your application on this occasion.

We appreciate the time you took to apply and wish you well in your search.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/application-rejected.blade.php ENDPATH**/ ?>