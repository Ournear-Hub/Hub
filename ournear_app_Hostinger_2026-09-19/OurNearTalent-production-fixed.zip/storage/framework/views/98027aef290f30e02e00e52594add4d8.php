<?php echo e($slot); ?>

<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>