<?php $__env->startComponent('mail::message'); ?>
# Application received

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($application->full_name); ?>,

Thank you for applying for **<?php echo new \Illuminate\Support\EncodedHtmlString($job?->title ?? 'this role'); ?>**. OurNear Talent has received your application and will review it.

You do not need a candidate account. We will contact you if we need more information.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/application-submitted-applicant.blade.php ENDPATH**/ ?>