<?php $__env->startComponent('mail::message'); ?>
# Interview scheduled

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($application->full_name); ?>,

Your interview for **<?php echo new \Illuminate\Support\EncodedHtmlString($job?->title ?? 'this role'); ?>** has been scheduled.

**Date and time:** <?php echo new \Illuminate\Support\EncodedHtmlString($interview->scheduled_at?->timezone(config('app.timezone'))->format('l, j F Y \a\t H:i')); ?>  
**Mode:** <?php echo new \Illuminate\Support\EncodedHtmlString(str_replace('_', ' ', $interview->mode->value)); ?>

<?php if(filled($interview->location_or_link)): ?>
**Location or meeting link:** <?php echo new \Illuminate\Support\EncodedHtmlString($interview->location_or_link); ?>

<?php endif; ?>

Please reply only if you need to reschedule. Bring any identification requested in the job listing.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/interview-scheduled.blade.php ENDPATH**/ ?>