<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia><?php echo e(! empty($publicSeo['title']) ? $publicSeo['title'].' - '.($publicSeo['og_site_name'] ?? config('app.name', 'OurNear Talent')) : config('app.name', 'OurNear Talent')); ?></title>
        <?php echo $__env->make('partials.public-seo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if(! empty($publicBranding['favicon_url'])): ?>
            <link head-key="favicon" rel="icon" href="<?php echo e($publicBranding['favicon_url']); ?>">
        <?php elseif(! empty($publicBranding['icon_url'])): ?>
            <link head-key="favicon" rel="icon" href="<?php echo e($publicBranding['icon_url']); ?>">
        <?php endif; ?>

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.tsx']); ?>
        <?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="antialiased">
        <?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } ?>
    </body>
</html>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/app.blade.php ENDPATH**/ ?>