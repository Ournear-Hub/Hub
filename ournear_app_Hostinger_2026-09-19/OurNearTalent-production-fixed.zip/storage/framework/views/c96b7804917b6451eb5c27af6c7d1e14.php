<?php if(! empty($publicSeo)): ?>
    <meta head-key="description" name="description" content="<?php echo e($publicSeo['description']); ?>">
    <link head-key="canonical" rel="canonical" href="<?php echo e($publicSeo['canonical']); ?>">
    <meta head-key="robots" name="robots" content="<?php echo e($publicSeo['robots']); ?>">
    <meta head-key="og:type" property="og:type" content="<?php echo e($publicSeo['og_type']); ?>">
    <meta head-key="og:title" property="og:title" content="<?php echo e($publicSeo['og_title']); ?>">
    <meta head-key="og:description" property="og:description" content="<?php echo e($publicSeo['og_description']); ?>">
    <meta head-key="og:url" property="og:url" content="<?php echo e($publicSeo['og_url']); ?>">
    <meta head-key="og:site_name" property="og:site_name" content="<?php echo e($publicSeo['og_site_name']); ?>">
    <?php if(! empty($publicSeo['og_image'])): ?>
        <meta head-key="og:image" property="og:image" content="<?php echo e($publicSeo['og_image']); ?>">
    <?php endif; ?>
    <meta head-key="twitter:card" name="twitter:card" content="<?php echo e($publicSeo['twitter_card']); ?>">
    <meta head-key="twitter:title" name="twitter:title" content="<?php echo e($publicSeo['twitter_title']); ?>">
    <meta head-key="twitter:description" name="twitter:description" content="<?php echo e($publicSeo['twitter_description']); ?>">
    <?php if(! empty($publicSeo['twitter_image'])): ?>
        <meta head-key="twitter:image" name="twitter:image" content="<?php echo e($publicSeo['twitter_image']); ?>">
    <?php endif; ?>
<?php endif; ?>
<?php if(! empty($publicAnalytics['enabled']) && ! empty($publicAnalytics['id'])): ?>
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($publicAnalytics['id']); ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', <?php echo json_encode($publicAnalytics['id'], 15, 512) ?>);
    </script>
<?php endif; ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/partials/public-seo.blade.php ENDPATH**/ ?>