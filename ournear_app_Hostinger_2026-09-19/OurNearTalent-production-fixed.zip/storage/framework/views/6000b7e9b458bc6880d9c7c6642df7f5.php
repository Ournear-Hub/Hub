<?php $__env->startComponent('mail::message'); ?>
# You have been selected

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($application->full_name); ?>,

We are pleased to confirm that you have been selected for **<?php echo new \Illuminate\Support\EncodedHtmlString($job?->title ?? 'this role'); ?>**.

OurNear Talent will contact you with next steps. This message is not an offer of employment.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OURNEAR TALENT\laravel-12.x\OurNearTalent\resources\views/mail/application-selected.blade.php ENDPATH**/ ?>